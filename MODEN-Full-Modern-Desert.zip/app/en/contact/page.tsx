import PageEL from '../../contact/page'
export default PageEL