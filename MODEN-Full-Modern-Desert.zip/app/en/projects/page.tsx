import PageEL from '../../projects/page'
export default PageEL