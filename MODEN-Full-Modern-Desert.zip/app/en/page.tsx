'use client'
import PageEL from '../page'
export default PageEL