import PageEL from '../../philosophy/page'
export default PageEL