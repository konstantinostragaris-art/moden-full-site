# MODEN Development — Modern Desert Edition

Next.js 14 + TypeScript + Tailwind + Framer Motion

Pages:
- /, /projects, /philosophy, /contact (+ /en versions)

Deploy on Vercel:
- Root Directory: (empty)
- Install: npm install
- Build: next build
- Output: .next
