/** @type {import('next').NextConfig} */
module.exports = { experimental:{ typedRoutes:true } }
